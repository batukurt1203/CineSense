// TODO: Implement WatchPartyPage
export default function WatchPartyPage() {
  return (
    <div style={{ padding: '4rem 2rem', textAlign: 'center' }}>
      <h1 style={{ fontFamily: 'var(--font-display)', color: 'var(--color-gold)', fontSize: '2rem' }}>WatchPartyPage</h1>
      <p style={{ color: 'var(--color-text-secondary)', marginTop: '1rem' }}>Coming soon — this page is a stub.</p>
    </div>
  )
}
